<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');

if (isset($_SESSION['id']) && !empty($_SESSION['id'])) {
    $id = $_SESSION['id'];

// SQL 쿼리
$sql = "SELECT authority FROM ui WHERE id = '$id'";

// 쿼리 실행
$result = mysqli_query($conn, $sql);

// 쿼리 결과 처리
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $authority = $row['authority'];
    // echo "사용자의 authority 값: " . $authority;
} else {
    // echo "사용자를 찾을 수 없습니다.";
}
    // 세션 변수가 존재하는 경우에 추가적인 처리를 수행합니다.
    echo '<div class="welcome-bar">';
    echo '<span class="welcome-text">' . $_SESSION['id'] . '님 환영합니다.</span>';
  
    echo '<a href="../board/moveboard.php"><button class="logout-button">게시판으로 이동</button></a>';
    echo '<a href="../index.php"><button class="logout-button">로그아웃</button></a>';
    echo '</div>';
} else {
    echo "<script>alert('세션이 만료되었습니다. 로그인을 해주십시오.') 
    location.href ='../index.php';
    </script>";
}
?>
<html>
  <head>
  <style>
    .welcome-bar {
      position: fixed;
      top: 0;
      right: 0;
      /* background-color: #f2f2f2; */
      padding: 10px;
      text-align: right;
    }
    
    .welcome-bar .welcome-text {
      display: inline-block;
      margin-right: 10px;
    }
    
    .welcome-bar .logout-button {
      display: inline-block;
      padding: 6px 12px;
      background-color: #333;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    .welcome-bar .logout-button:hover {
      background-color: #555;
    }
  </style>


</head>
<body>
  <?php
  ?>
</body>
</html>
