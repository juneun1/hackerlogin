<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
// include "session.php";

$authority = $_SESSION['authority']; // 세션에서 권한 값을 가져옴

$sql = "SELECT * FROM ui WHERE authority = '".$authority."'";

$result = mysqli_query($conn, $sql);

if ($result) {
    $user_check = mysqli_fetch_assoc($result);
    echo $user_check['authority'];
} else {
    echo "데이터를 가져오는 데 실패했습니다.";
}

mysqli_close($conn);
?>
