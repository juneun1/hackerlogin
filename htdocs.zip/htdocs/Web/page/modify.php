<!--- 게시글 수정 -->
<?php
    $conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
    include "../member/session.php";
    // include "../db/db.php"; 
    $bno = $_GET['idx'];
    $sql = "SELECT * FROM board WHERE idx='$bno'";
    $result = mysqli_query($conn, $sql);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $board = mysqli_fetch_array($result);
        // 나머지 코드 작성
    } else {
        echo "게시물을 불러오는 데 실패했습니다.";
    }
?>

<!doctype html>
<head>
<meta charset="UTF-8">
<title>게시판</title>
<!-- <link rel="stylesheet" href="/css/style.css" /> -->
</head>
<body>
    <div id="board_write">
        <h1><a href="/">자유게시판</a></h1>
        <h4>글을 수정합니다.</h4>
            <div id="write_area">
                <form action="../action/modify_ok.php?idx=<?php echo $bno; ?>" method="post">
                    <div id="in_title">
                        <textarea name="title" id="title" rows="1" cols="55" placeholder="제목" maxlength="100" required><?php echo $board['title']; ?></textarea>
                    </div>
                    <div class="wi_line"></div>
                    <div id="in_name">
                        <p name="name" id="user_name" rows="1" cols="55" maxlength="100" required><?php echo "작성자 : " .$board['user_name']; ?></p>
                    </div>
                    <div class="wi_line"></div>
                    <div id="in_content">
                        <textarea name="content" id="content" placeholder="내용" required><?php echo $board['content']; ?></textarea>
                    </div>
                    <div class="bt_se">
                        <button type="submit">수정하기</button>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>