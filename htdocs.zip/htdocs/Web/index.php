<?php 
$conn= mysqli_connect('localhost', 'root', '123456', 'userinfo');
?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8" />
	<title>회원가입 및 로그인 사이트</title>
<link rel="stylesheet" type="text/css" href="/css/common.css" />
</head>
<body>
	<div id="login_box">
		<h1>로그인</h1>							
			<form method="post" action="action/login_ok.php">
				<table cellspacing="0" width="300">
        			<tr>
            			<td width="130" colspan="1"> 
                		<input type="text" name="id" class="inph">
            		</td>
            		<td rowspan="2"  width="100" > 
                		<button type="submit" id="btn" >로그인</button>
            		</td>
        		</tr>
        		<tr>
            		<td width="130" colspan="1"> 
               		<input type="password" name="pw" class="inph">
            	</td>
        	</tr>
        	<tr>
           		<td class="mem"> 
				   <a href="member/member.php">회원가입 하시겠습니까?</a>

           </td>
        </tr>
    </table>
  </form>

</div>
</body>
</html>