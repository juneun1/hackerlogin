<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');

include "../member/session.php";

// 페이지 번호를 GET 파라미터로 받아옴
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$postsPerPage = 10; // 페이지 당 표시할 게시물 수

// 정렬 기준을 GET 파라미터로 받아옴
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'idx';
$validSorts = array('idx', 'hit', 'best');

// 전체 게시물 수 조회
$totalPostsQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM board");
$totalPostsResult = mysqli_fetch_assoc($totalPostsQuery);
$totalPosts = $totalPostsResult['total'];

// 전체 페이지 수 계산
$totalPages = ceil($totalPosts / $postsPerPage);

// 현재 페이지 번호가 유효한 범위인지 확인
if ($page < 1 || $page > $totalPages) {
    // 유효하지 않은 페이지 번호라면 첫 페이지로 이동
    header("Location: general.php?page=1&sort=$sort");
    exit;
}

// 정렬 기준이 유효한지 확인
if (!in_array($sort, $validSorts)) {
    // 유효하지 않은 정렬 기준이라면 idx 순서로 설정
    $sort = 'idx';
}

// 현재 페이지에 해당하는 게시물 조회
$offset = ($page - 1) * $postsPerPage;

// 정렬 기준에 따라 쿼리를 구성하여 조회
$postsQuery = mysqli_query($conn, "SELECT * FROM board ORDER BY $sort DESC LIMIT $offset, $postsPerPage");
?>


<!doctype html>
<head>
<meta charset="UTF-8">
<title>게시판</title>
<!-- <link rel="stylesheet" type="text/css" href="/css/style.css" /> -->
</head>
<body>
  
<div id="board_area"> 
  <h1>자유게시판</h1>
    <table class="list-table">
      <thead>
          <tr>
              <th width="70">번호</th>
              <th width="500">제목</th>
              <th width="120">글쓴이</th>
              <th width="100">작성일</th>
              <th width="100">조회수</th>
              <th width="100">추천수</th>
          </tr>
      </thead>
      <tbody>
        <?php
        while ($board = mysqli_fetch_array($postsQuery)) {
            $title = $board["title"];
            if (strlen($title) > 30) {
                // 30자 넘어가면 생략 
                $title = str_replace($board["title"], mb_substr($board["title"], 0, 30, "utf-8")."...",$board["title"]);
            }
        ?>
        <tr>
          <td width="100"><?php echo $board['idx']; ?></td>
          <td width="500"><a href="../action/read.php?idx=<?php echo $board["idx"];?>"><?php echo $title;?></a></td>
          <td width="300"><?php echo $board['user_name']; ?></td>
          <td width="400"><?php echo $board['reg_date']; ?></td>
          <td width="500"><?php echo $board['hit']; ?></td>
          <td width="600"><?php echo $board['best']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
    <div id="write_btn">
      <a href="../action/write.php"><button>글쓰기</button></a>
    </div>
    
    <!-- 정렬 버튼 -->
    <div class="sort-buttons">
      <a href="general.php?page=<?php echo $page; ?>&sort=idx">번호순</a>
      <a href="general.php?page=<?php echo $page; ?>&sort=hit">조회순</a>
      <a href="general.php?page=<?php echo $page; ?>&sort=best">추천순</a>
    </div>

  <!-- 페이지 네비게이션 출력 -->
  <div class="pagination">
    <?php if ($page > 1): ?>
        <a href="general.php?page=<?php echo $page - 1; ?>">이전</a>
    <?php endif; ?>

    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <?php if ($i == $page): ?>
            <span><?php echo $i; ?></span>
        <?php else: ?>
            <a href="general.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($page < $totalPages): ?>
        <a href="general.php?page=<?php echo $page + 1; ?>">다음</a>
    <?php endif; ?>
  </div>
    
</body>
</html>
