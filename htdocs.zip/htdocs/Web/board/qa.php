<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');

// 페이지 번호를 GET 파라미터로 받아옴
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$postsPerPage = 10; // 페이지 당 표시할 게시물 수

// 전체 게시물 수 조회
$totalPostsQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM qa");
$totalPostsResult = mysqli_fetch_assoc($totalPostsQuery);
$totalPosts = $totalPostsResult['total'];

// 전체 페이지 수 계산
$totalPages = ceil($totalPosts / $postsPerPage);

// 현재 페이지 번호가 유효한 범위인지 확인
if ($page < 1 || $page > $totalPages) {
    // 유효하지 않은 페이지 번호라면 첫 페이지로 이동
    header("Location: qa.php?page=1");
    exit;
}

// 현재 페이지에 해당하는 게시물 조회
$offset = ($page - 1) * $postsPerPage;
$postsQuery = mysqli_query($conn, "SELECT * FROM qa ORDER BY idx DESC LIMIT $offset, $postsPerPage");

?>

<!-- 게시판 목록 출력 -->
<table>
    <tr>
        <th>순번</th>
        <th>제목</th>
        <th>글쓴이</th>
        <th>작성일</th>
        <th>조회수</th>
        <th>답글</th>
    </tr>
    <?php while ($post = mysqli_fetch_assoc($postsQuery)): ?>
    <tr>
        <td><?php echo $post['idx']; ?></td>
        <td><?php echo $post['title']; ?></td>
        <td><?php echo $post['name']; ?></td>
        <td><?php echo $post['date']; ?></td>
        <td><?php echo $post['hit']; ?></td>
        <td><a href="/BBS/reply.php?idx=<?php echo $post['idx']; ?>">[답글]</a></td>
    </tr>
    <?php endwhile; ?>
</table>

<!-- 페이지 네비게이션 출력 -->
<div class="pagination">
    <?php if ($page > 1): ?>
        <a href="/BBS/index.php?page=<?php echo $page - 1; ?>">이전</a>
    <?php endif; ?>

    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <?php if ($i == $page): ?>
            <span><?php echo $i; ?></span>
        <?php else: ?>
            <a href="/BBS/index.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($page < $totalPages): ?>
        <a href="/BBS/index.php?page=<?php echo $page + 1; ?>">다음</a>
    <?php endif; ?>
</div>

<?php mysqli_close($conn); ?>
