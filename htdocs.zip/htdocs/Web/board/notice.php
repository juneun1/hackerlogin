<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
include "../member/session.php";

// 페이지 번호를 GET 파라미터로 받아옴
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$postsPerPage = 10; // 페이지 당 표시할 공지사항 수

// 정렬 기준을 GET 파라미터로 받아옴
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'latest';
$validSorts = array('latest', 'hit', 'idx');

// 전체 공지사항 수 조회
$totalPostsQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM notice");
$totalPostsResult = mysqli_fetch_assoc($totalPostsQuery);
$totalPosts = $totalPostsResult['total'];

// 전체 페이지 수 계산
$totalPages = ceil($totalPosts / $postsPerPage);

// 현재 페이지 번호가 유효한 범위인지 확인
if ($page < 1 || $page > $totalPages) {
    // 유효하지 않은 페이지 번호라면 첫 페이지로 이동
    header("Location: notice.php?page=1&sort=$sort");
    exit;
}

// 정렬 기준이 유효한지 확인
if (!in_array($sort, $validSorts)) {
    // 유효하지 않은 정렬 기준이라면 최신순으로 설정
    $sort = 'latest';
}

// 현재 페이지에 해당하는 공지사항 조회
$offset = ($page - 1) * $postsPerPage;

// 정렬 기준에 따라 쿼리를 구성하여 조회
if ($sort === 'latest') {
    $postsQuery = mysqli_query($conn, "SELECT * FROM notice ORDER BY idx DESC LIMIT $offset, $postsPerPage");
} else if ($sort === 'hit') {
    $postsQuery = mysqli_query($conn, "SELECT * FROM notice ORDER BY hit DESC LIMIT $offset, $postsPerPage");
} else if ($sort === 'idx') {
    $postsQuery = mysqli_query($conn, "SELECT * FROM notice ORDER BY idx LIMIT $offset, $postsPerPage");
}
?>

<!doctype html>
<head>
<meta charset="UTF-8">
<title>게시판</title>
<!-- <link rel="stylesheet" type="text/css" href="/css/style.css" /> -->
</head>
<body>
<div id="board_area"> 
  <h1>공지사항</h1>
    <table class="list-table">
      <thead>
          <tr>
              <th width="70">번호</th>
              <th width="500">제목</th>
              <th width="120">글쓴이</th>
              <th width="100">작성일</th>
              <th width="100">조회수</th>
              <th width="100">추천수</th>
          </tr>
      </thead>
      <tbody>
        <?php while ($notice = mysqli_fetch_array($postsQuery)) {
            $title = $notice["title"];
            if (strlen($title) > 30) {
                // 30자 넘어가면 생략 
                $title = str_replace($notice["title"], mb_substr($notice["title"], 0, 30, "utf-8")."...",$notice["title"]);
            }
        ?>
        <tr>

          <td width="100"><?php echo $notice['idx']; ?></td>
          <td width="500"><a href="notice_read.php?idx=<?php echo $notice["idx"];?>"><?php echo $title;?></a></td>
          <td width="300"><?php echo $notice['user_name']; ?></td>
          <td width="400"><?php echo $notice['reg_date']; ?></td>
          <td width="500"><?php echo $notice['hit']; ?></td>
          <td width="600"><?php echo $notice['best']; ?></td>     
        </tr>
        <?php } ?>
      </tbody>
    </table>
    <div id="write_btn">
      <a href="../board/notice_write.php">
			<?php
			if($authority == 'admin' ){
				?><button>글쓰기</button>
			<?php 
		}?>       
    </div>
  </div>
  <!-- 버튼 추가: 정렬 기준 선택 -->
<div class="sort-buttons">
    <a href="notice.php?page=<?php echo $page; ?>&sort=latest">최신순</a>
    <a href="notice.php?page=<?php echo $page; ?>&sort=hit">조회순</a>
</div>

  <!-- 페이지 네비게이션 출력 -->
  <div class="pagination">
    <?php if ($page > 1): ?>
        <a href="notice.php?page=<?php echo $page - 1; ?>">이전</a>
    <?php endif; ?>

    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <?php if ($i == $page): ?>
            <span><?php echo $i; ?></span>
        <?php else: ?>
            <a href="notice.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($page < $totalPages): ?>
        <a href="notice.php?page=<?php echo $page + 1; ?>">다음</a>
    <?php endif; ?>
  </div>
</body>
</html>
