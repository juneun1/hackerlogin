<?php
// 데이터베이스에 연결하고 필요한 파일을 포함합니다.
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
include "../member/session.php";

// URL에서 'idx' 파라미터가 전달되었는지 확인합니다.
if (isset($_GET['idx'])) {
    $parentIdx = intval($_GET['idx']);

    // 부모 게시물의 정보를 가져옵니다.
    $parentPostQuery = mysqli_query($conn, "SELECT * FROM board WHERE idx = $parentIdx");
    $parentPost = mysqli_fetch_assoc($parentPostQuery);
}

// 폼이 제출되었는지 확인합니다.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = $_POST['content'];
    $userName = $member;

    // 답글을 'replay' 테이블에 추가합니다.
    mysqli_query($conn, "INSERT INTO replay (idx, user_name, content, date) VALUES ($parentIdx, '$userName', '$content', NOW())");

    // 답글 작성 후 부모 게시물로 이동합니다.
    header("Location: ../action/read.php?idx=$parentIdx");
    exit;
}
?>

<!doctype html>
<head>
    <meta charset="UTF-8">
    <title>답글 작성</title>
</head>
<body>
    <h1>답글 작성</h1>
    <h2>원본 글</h2>
    <table>
        <tr>
            <td>제목:</td>
            <td><?php echo $parentPost['title']; ?></td>
        </tr>
        <tr>
            <td>작성자:</td>
            <td><?php echo $parentPost['user_name']; ?></td>
        </tr>
        <tr>
            <td>작성일:</td>
            <td><?php echo $parentPost['date']; ?></td>
        </tr>
        <tr>
            <td>내용:</td>
            <td><?php echo $parentPost['content']; ?></td>
        </tr>
    </table>

    <h2>답글 작성</h2>
    <form method="post" action="reply.php?idx=<?php echo $parentIdx; ?>">
        <textarea name="content" rows="5" cols="50" required></textarea><br>
        <input type="submit" value="답글 작성">
    </form>
</body>
</html>
