<?php 
    $conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
    include_once "../member/session.php"
    
?>

<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8" />
        <title>게시판</title>
</head>
<body>
    <a href="notice.php">공지사항</a>
    <a href="general.php">자유게시판</a>
    <a href="qa.php">Q&A</a>
</body>
    </html>
