<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
include "../member/session.php";
?>

<!doctype html>
<head>
<meta charset="UTF-8">
<title>게시판</title>
</head>
<body>
	<?php
		if (!isset($_GET['idx'])) {
			echo "게시물을 불러오는 데 실패했습니다.";
			exit;
		}
		$idx = $_GET['idx'];
		$sql = "SELECT * FROM notice WHERE idx = '".$idx."'";
		$result = mysqli_query($conn, $sql);
		if ($result && mysqli_num_rows($result) > 0) {
			$row = mysqli_fetch_array($result);
			$hit = $row['hit'] + 1;
			$sql = "UPDATE notice SET hit = '".$hit."' WHERE idx = '".$idx."'";
			mysqli_query($conn, $sql);
			$sql = "SELECT * FROM notice WHERE idx = '".$idx."'";
			$result = mysqli_query($conn, $sql);
			if ($result && mysqli_num_rows($result) > 0) {
				$notice = mysqli_fetch_array($result);
?>
<!-- 글 불러오기 -->
<div id="notice_read">
	<h2><?php echo $notice['title']; ?></h2>
	<div id="user_info">
		<?php echo $notice['user_name']; ?> <?php echo $notice['reg_date']; ?> 조회:<?php echo $notice['hit']; ?>
		<div id="bo_line"></div>
	</div>
	<div id="bo_content">
		<?php echo nl2br($notice['content']); ?>
	</div>
	<!-- 목록, 수정, 삭제 -->

	<div id="bo_ser">
		<ul>
			<li><a href="../board/general.php">[목록으로]</a></li>

			<?php
			if($authority == 'admin' ){
				?>
			<li><a href="../page/modify.php?idx=<?php echo $notice['idx']; ?>">[수정]</a></li>
			<li><a href="notice_del.php?idx=<?php echo $notice['idx']; ?>">[삭제]</a></li>
			<?php
		}?></div>
		
		</ul>
</div>
<?php
			} else {
				echo "게시물을 불러오는 데 실패했습니다.";
			}
		} else {
			echo "게시물을 불러오는 데 실패했습니다.";
		}
?>
</body>
</html>
