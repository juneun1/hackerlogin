<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
include "../member/session.php";
$bno = isset($_GET['idx']) ? $_GET['idx'] : '';
// $user_name = isset($_POST['user_name']) ? $_POST['user_name'] : '';
$content = isset($_POST['content']) ? $_POST['content'] : '';

$user_name = $_SESSION['id'];
if ($bno && $content) {
    $sql = "INSERT INTO replay (idx, user_name, content ) VALUES ('$bno', '$user_name', '$content')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script>alert('댓글이 작성되었습니다.'); location.href='../action/read.php?idx=$bno';</script>";
    } else {
        echo $result;
        // echo "<script>alert('댓글 작성에 실패했습니다.'); history.back();</script>";
    }
} else {
    echo $sql;

    // echo "<script>alert('댓글 작성에 실패했습니다.'); history.back();</script>";
}
?>
