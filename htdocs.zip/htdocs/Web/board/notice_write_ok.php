<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
session_start();
date_default_timezone_set('Asia/Seoul');

$user_name = $_SESSION['id'];
$title = $_POST['title'];
$content = $_POST['content'];
$reg_date = date('Y-m-d H:i:s');


if ($title && $content) {
    $sql = "INSERT INTO notice (title, user_name, content, reg_date) 
            VALUES ('$title', '$user_name', '$content', '$reg_date')";
    
    if (mysqli_query($conn, $sql)) {
        $last_insert_id = mysqli_insert_id($conn); // 새로 추가된 글의 idx 가져오기
        echo "<script>alert('글쓰기 완료되었습니다. 새로 작성한 글의 번호는 $last_insert_id 입니다.');</script>";
        echo "<script>location.href='../board/notice.php';</script>";
        // 여기서 추가적인 처리나 리다이렉션을 수행할 수 있습니다.
    } else {
        echo "글쓰기에 실패했습니다.";
        // 실패 시에 대한 처리나 에러 메시지 출력을 수행할 수 있습니다.
    }
} else {
    echo "<script>alert('제목과 내용을 입력해주세요.');</script>";
    echo "<script>history.back();</script>";
}
?>
