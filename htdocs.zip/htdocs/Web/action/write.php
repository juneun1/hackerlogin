<?php 
    include "../member/session.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>게시판</title>
<link rel="stylesheet" type="text/css" href="../css/style.css" />
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    
    #board_write {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
    }
    
    #board_write h1 {
        font-size: 24px;
        margin-bottom: 10px;
    }
    
    #board_write h4 {
        font-size: 14px;
        margin-bottom: 20px;
    }
    
    #write_area {
        background-color: #f2f2f2;
        padding: 20px;
        border-radius: 4px;
    }
    
    #in_title textarea,
    #in_name textarea,
    #in_content textarea,
    #in_pw input {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        resize: vertical;
    }
    
    .wi_line {
        height: 1px;
        background-color: #ccc;
        margin-top: 10px;
        margin-bottom: 20px;
    }
    
    .bt_se button {
        padding: 10px 20px;
        background-color: #333;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    
    .bt_se button:hover {
        background-color: #555;
    }
</style>
</head>
<body>
    <div id="board_write">
        <h1><a href="/">자유게시판입니다</a></h1>
        
        <div id="write_area">
            <form action="write_ok.php" method="post">
                <div id="in_title">
                    <textarea name="title" id="title" rows="1" cols="55" placeholder="제목" maxlength="100" required></textarea>
                </div>
                <div class="wi_line"></div>
                <div id="in_name">
                    <?php 
                        echo "작성자 : " .$_SESSION['id'];
                    ?>
                    <!-- <textarea name="name" id="uname" rows="1" cols="55" placeholder="글쓴이" maxlength="100" required></textarea> -->
                </div>
                <div class="wi_line"></div>
                <div id="in_content">
                    <textarea name="content" id="content" placeholder="내용" required></textarea>
                </div>
                <form action="upload.php"method="post"
                 enctpye="width=device-with, initial-scal=1.0">
                    <input type="file" name="ufile">
                    <button>업로드</button>
                
                <div class="bt_se">
                    <button type="submit">글 작성</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
