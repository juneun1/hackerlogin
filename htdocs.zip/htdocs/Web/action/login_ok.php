<meta charset="utf-8" />
<?php	
    $conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
    include "../password.php";

    // POST로 받아온 아이디와 비밀번호가 비어있다면 알림창을 띄우고 이전 페이지로 돌아갑니다.
    if ($_POST["id"] == "" || $_POST["pw"] == "") {
        echo '<script> alert("아이디나 패스워드를 입력하세요."); history.back(); </script>';
    } else {
        // password 변수에 POST로 받아온 값을 저장하고 SQL 문으로 POST로 받아온 아이디값을 찾습니다.
        $pw = $_POST['pw'];
        $hashed_pw = password_hash($pw, PASSWORD_DEFAULT);
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $sql = "SELECT * FROM ui WHERE id='".$id."'";
        $result = mysqli_query($conn, $sql);

        if (!$result) {
            die('쿼리 실행에 실패했습니다: ' . mysqli_error($conn));
        }

        $member = $result->fetch_array();
        $hash_pw = $member['pw'];

        if (password_verify($pw, $hash_pw)) {
            // 비밀번호가 일치할 때의 처리
            session_start();
            $_SESSION['id'] = $member["id"];
            $_SESSION['pw'] = $member["pw"];
            
            //$_SESSION['id'] = true;
            
            echo "<script>alert('로그인되었습니다.'); location.href='../member/session.php';</script>";
        } else {
            // 비밀번호가 일치하지 않을 때의 처리
            echo "<script>alert('아이디 혹은 비밀번호를 확인하세요.'); history.back();</script>";
        }
    }
?>

