<?php

move_uploaded_file($_FILES['ufile']['tmp_name'], $tfile);

?>