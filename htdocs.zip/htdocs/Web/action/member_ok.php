<?php

	$conn= mysqli_connect('localhost', 'root', '123456', 'userinfo');
	$id = $_POST['id'];
	$pw = password_hash($_POST['pw'], PASSWORD_DEFAULT);
	$name = $_POST['name'];
	$email = $_POST['email'];
	$email_check;
	
	$mq = "
		INSERT INTO ui(id, pw, name, email, email_check) VALUES ('{$id}', '{$pw}', '{$name}','{$email}', '0' );
	";
	$res = mysqli_multi_query($conn,$mq);

	if ($res) {
		echo "<script>alert('회원가입이 완료되었습니다.')
		location.href ='../page/main.php';
	   </script>";
		exit;
			} 
		else {
		echo "<script>alert('저장에 문제가 생겼습니다. 관리자에게 문의해주세요.');</script>";  
		echo "<script>console.log('" . mysqli_error($conn) . "');</script>";
			}
?>
<meta charset="utf-8" />
<!-- <script type="text/javascript">alert('회원가입이 완료되었습니다.');</script> -->
<!-- <meta http-equiv="refresh" content="0 url=/"> -->