<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');

if (!$conn) {
    die("데이터베이스 연결 실패: " . mysqli_connect_error());
}

session_start();
if (!isset($_SESSION['id'])) {
    echo "<script>alert('로그인 후에 추천할 수 있습니다.'); location.href='../index.php';</script>";
    exit;
}

$memberId = $_SESSION['id'];
$bno = $_GET['idx'];

// 중복 추천 체크
$checkQuery = "SELECT * FROM recommendations WHERE id='$memberId' AND idx='$bno'";
$result = mysqli_query($conn, $checkQuery);
if (!$result) {
    echo "쿼리 실행에 실패했습니다: " . mysqli_error($conn);
    exit;
}

if (mysqli_num_rows($result) > 0) {
    echo "<script>alert('이미 추천한 게시물입니다.'); location.href='../board/general.php';</script>";
    exit;
}

// 추천 기록 추가
$insertQuery = "INSERT INTO recommendations (id, idx) VALUES ('$memberId', '$bno')";
if (mysqli_query($conn, $insertQuery)) {
    // 추천 수 업데이트
    $updateQuery = "UPDATE board SET best = best + 1 WHERE idx='$bno'";
    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('추천되었습니다.'); location.href='../board/general.php';</script>";
    } else {
        echo "추천 실패: " . mysqli_error($conn);
    }
} else {
    echo "추천 실패: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
