<?php
    $conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
	session_destroy();
?>
<meta charset="utf-8">
<script>alert("로그아웃되었습니다."); location.href="../index.php"; </script>