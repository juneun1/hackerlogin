<?php
$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
include "../member/session.php";
?>

<!doctype html>
<head>
<meta charset="UTF-8">
<title>게시판</title>
</head>
<body>
	<?php
		if (!isset($_GET['idx'])) {
			echo "게시물을 불러오는 데 실패했습니다.";
			exit;
		}
		$idx = $_GET['idx'];
		$sql = "SELECT * FROM board WHERE idx = '".$idx."'";
		$result = mysqli_query($conn, $sql);
		if ($result && mysqli_num_rows($result) > 0) {
			$row = mysqli_fetch_array($result);
			$hit = $row['hit'] + 1;
			$sql = "UPDATE board SET hit = '".$hit."' WHERE idx = '".$idx."'";
			mysqli_query($conn, $sql);
			$sql = "SELECT * FROM board WHERE idx = '".$idx."'";
			$result = mysqli_query($conn, $sql);
			if ($result && mysqli_num_rows($result) > 0) {
				$board = mysqli_fetch_array($result);
?>
<!-- 글 불러오기 -->
<div id="board_read">
	<h2><?php echo $board['title']; ?></h2>
	<div id="user_info">
		<?php echo $board['user_name']; ?> <?php echo $board['reg_date']; ?> 조회:<?php echo $board['hit']; ?>
		<div id="bo_line"></div>
	</div>
	<div id="bo_content">
		<?php echo nl2br($board['content']); ?>
	</div>
	<!-- 목록, 수정, 삭제 -->
	<div id="bo_ser">
		<ul>
			<li><a href="../board/general.php">[목록으로]</a></li>

			<?php
			if($board['user_name']==$_SESSION['id'] ||  $authority == 'admin' ){
				?>
			<li><a href="../page/modify.php?idx=<?php echo $board['idx']; ?>">[수정]</a></li>
		
			<li><a href="delete.php?idx=<?php echo $board['idx']; ?>">[삭제]</a></li>
			<?php
		}?></div>
			<li><a href="good.php?idx=<?php echo $board['idx']; ?>">[추천]</a></li>
		</ul>
	</div>
</div>
<div class="reply_view">
    <h3>댓글목록</h3>
    <?php
        $sql3 = mysqli_query($conn, "SELECT * FROM replay WHERE idx='".$idx."' ORDER BY idx DESC");
        while($replay = mysqli_fetch_array($sql3)) { 
    ?>
    <div class="dap_lo">
        <div><b><?php echo "작성자: " .$replay['user_name'];?></b></div>
        <div class="dap_to comt_edit"><?php echo nl2br("$replay[content]"); ?></div>
        <div class="rep_me dap_to"><?php echo $replay['date']; ?></div>
        <div class="rep_me rep_menu">
            <a class="dat_edit_bt" href="#">수정</a>
            <a class="dat_delete_bt" href="#">삭제</a>
        </div>
        <!-- 댓글 수정 폼 dialog -->
        <div class="dat_edit">
            <form method="post" action="/BBS/rep_modify_ok.php">
                <input type="hidden" name="rno" value="<?php echo $replay['idx']; ?>" />
                <input type="hidden" name="b_no" value="<?php echo $idx; ?>">
                
            </form>
        </div>
        
    </div>
    <?php } ?>

    <!--- 댓글 입력 폼 -->
    <div class="dap_ins">
        <form action="../board/replay_ok.php?idx=<?php echo $idx; ?>" method="post">
            <?php echo $_SESSION['id'] ?>
            <div style="margin-top:10px; ">
                <textarea name="content" class="reply_content" id="re_content" ></textarea>
                <button id="rep_bt" class="re_bt">댓글</button>
            </div>
        </form>
    </div>
</div>
<!--- 댓글 불러오기 끝 -->

<div id="foot_box"></div>
</div>
<?php
			} else {
				echo "게시물을 불러오는 데 실패했습니다.";
			}
		} else {
			echo "게시물을 불러오는 데 실패했습니다.";
		}
?>


</body>
</html>
