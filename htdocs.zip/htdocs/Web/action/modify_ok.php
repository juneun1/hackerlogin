<?php 

$conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
include "../member/session.php";

$bno = $_GET['idx']; // $bno(hidden)에 idx값을 받아와 넣음

$date = date('Y-m-d h:i:s'); 
/* 받아온 idx값을 선택해서 게시글 수정 */
$sql = ("UPDATE
      board 
   SET
      reg_date = '".$date."', 
      title='".$_POST['title']."',
      content='".$_POST['content']."' 
   where 
      idx='".$bno."'
");
$res = mysqli_multi_query($conn,$sql);
?>
<script>
   alert("수정되었습니다.");
</script>
<meta http-equiv="refresh" content="0 url=read.php?idx=<?=$bno?>">

