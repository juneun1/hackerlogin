<?php
    $conn = mysqli_connect('localhost', 'root', '123456', 'userinfo');
    include "../member/session.php";
	$bno = $_GET['idx'];
	$sql = "DELETE FROM board WHERE idx='".$bno."';";
    $res = mysqli_multi_query($conn,$sql);
?>
<script type="text/javascript">alert("삭제되었습니다.");</script>
<meta http-equiv="refresh" content="0 url=../board/general.php" />